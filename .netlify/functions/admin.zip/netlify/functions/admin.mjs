
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/blobsClient.js
import { getStore } from "@netlify/blobs";
var memoryStore = /* @__PURE__ */ new Map();
var STORE_NAME = "kutz_platform";
var DEFAULT_SHOP_SLUG = "kutz-madrid";
var DEFAULT_SHOP_CONFIG = {
  slug: "kutz-madrid",
  name: "KUTZ // BARBER STUDIO",
  pin: "1234",
  status: "active",
  phone: "+34 912 345 678",
  address: "Calle de Fuencarral 42, Madrid",
  logo: "https://luminadesk-gary.netlify.app/logo.png",
  barbers: [
    { id: "rex", name: "REX", specialty: "Degradados & Skin Fade", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300" },
    { id: "kiko", name: "KIKO", specialty: "Corte & Street", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300" },
    { id: "nico", name: "NICO", specialty: "Barba & Tijera", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=300" }
  ],
  services: [
    { id: "skin-fade", name: "Skin Fade #000 + Navaja", durationMinutes: 30, price: 18, description: "Degradado afeitado a cero con navaja y acabado mate" },
    { id: "taper-fade", name: "Low Taper + Ritual Toalla", durationMinutes: 35, price: 20, description: "Taper bajo pulido con toalla caliente infusionada" },
    { id: "beard-ritual", name: "Barba & Vapor de Ozono", durationMinutes: 25, price: 15, description: "Afeitado cl\xE1sico con vaporizador y b\xE1lsamo" },
    { id: "full-combo", name: "Full Combo (Corte + Barba)", durationMinutes: 50, price: 30, description: "Servicio completo de corte degradado y arreglo de barba" }
  ],
  schedule: {
    openTime: "10:00",
    closeTime: "20:30",
    slotIntervalMinutes: 30,
    workDays: [1, 2, 3, 4, 5, 6],
    daysOpen: [1, 2, 3, 4, 5, 6]
    // Mon-Sat
  },
  createdAt: 1763e9,
  updatedAt: 1763e9
};
var DEFAULT_CLIENTS = [
  {
    id: "1",
    name: "Marcos Varela",
    phone: "+34 611 223 344",
    treatment: "Mid Fade + Barba",
    treatments: [
      {
        id: "t-1",
        name: "Mid Fade + Barba",
        formula: "Base #0.5 \u2192 Peine #1.5 palanca abierta. Barba perfilada con navaja",
        notes: "Remolino en coronilla derecha; peinar hacia adelante",
        date: "28 Oct 2026",
        timestamp: 17616096e5
      }
    ],
    reliabilityScore: 100,
    noShowCount: 0
  },
  {
    id: "2",
    name: "Dani Morales",
    phone: "+34 633 445 566",
    treatment: "Low Taper + Ritual Toalla",
    treatments: [
      {
        id: "t-2",
        name: "Low Taper + Ritual Toalla",
        formula: "Taper bajo en patillas y nuca. Tijera texturizada superior",
        notes: "Piel sensible en cuello; usar loci\xF3n sin alcohol",
        date: "29 Oct 2026",
        timestamp: 1761696e6
      }
    ],
    reliabilityScore: 95,
    noShowCount: 0
  },
  {
    id: "3",
    name: "\xC1lex Rivera",
    phone: "+34 622 334 455",
    treatment: "Skin Fade #000 + Navaja",
    treatments: [
      {
        id: "t-3",
        name: "Skin Fade #000 + Navaja",
        formula: "Base Shaver #000 \u2192 #0.5 \u2192 #1.5. Acabado mate polvo volumen",
        notes: "Pelo grueso muy denso. Pulir bien zona occipital",
        date: "29 Oct 2026",
        timestamp: 1761696e6
      }
    ],
    reliabilityScore: 100,
    noShowCount: 0
  }
];
function isBlobsConfigured() {
  if (typeof process === "undefined" || !process.env) return false;
  return Boolean(
    process.env.NETLIFY_BLOBS_CONTEXT || process.env.NETLIFY_SITE_ID && process.env.NETLIFY_TOKEN || process.env.NETLIFY && process.env.NETLIFY_SITE_ID
  );
}
function getKutzStore() {
  let realStore = null;
  if (isBlobsConfigured()) {
    try {
      realStore = getStore({
        name: STORE_NAME,
        consistency: "strong"
      });
    } catch (err) {
      console.warn("[BlobsClient] Netlify Blobs init fallback to memory:", err?.message);
    }
  }
  const memAdapter = {
    async get(key, options = {}) {
      const val = memoryStore.get(key);
      if (val === void 0 || val === null) return null;
      if (options.type === "json") {
        try {
          return typeof val === "string" ? JSON.parse(val) : val;
        } catch {
          return null;
        }
      }
      return val;
    },
    async getJSON(key) {
      const val = memoryStore.get(key);
      if (val === void 0 || val === null) return null;
      try {
        return typeof val === "string" ? JSON.parse(val) : val;
      } catch {
        return null;
      }
    },
    async set(key, value) {
      memoryStore.set(key, typeof value === "string" ? value : JSON.stringify(value));
    },
    async setJSON(key, value) {
      memoryStore.set(key, JSON.stringify(value));
    },
    async delete(key) {
      memoryStore.delete(key);
    },
    async list(options = {}) {
      const prefix = options.prefix || "";
      const blobs = [];
      for (const [k] of memoryStore.entries()) {
        if (k.startsWith(prefix)) {
          blobs.push({ key: k });
        }
      }
      return { blobs };
    }
  };
  if (!realStore) return memAdapter;
  return {
    async get(key, options = {}) {
      try {
        return await realStore.get(key, options);
      } catch {
        return memAdapter.get(key, options);
      }
    },
    async getJSON(key) {
      try {
        if (typeof realStore.getJSON === "function") {
          return await realStore.getJSON(key);
        }
        return await realStore.get(key, { type: "json" });
      } catch {
        return memAdapter.getJSON(key);
      }
    },
    async set(key, value) {
      await memAdapter.set(key, value);
      try {
        await realStore.set(key, typeof value === "string" ? value : JSON.stringify(value));
      } catch {
      }
    },
    async setJSON(key, value) {
      await memAdapter.setJSON(key, value);
      try {
        if (typeof realStore.setJSON === "function") {
          await realStore.setJSON(key, value);
        } else {
          await realStore.set(key, JSON.stringify(value));
        }
      } catch {
      }
    },
    async delete(key) {
      await memAdapter.delete(key);
      try {
        await realStore.delete(key);
      } catch {
      }
    },
    async list(options = {}) {
      try {
        return await realStore.list(options);
      } catch {
        return memAdapter.list(options);
      }
    }
  };
}
async function getShopConfig(shopSlug) {
  const store = getKutzStore();
  const key = `shops/${shopSlug}/config`;
  let config2 = await store.getJSON(key);
  if (!config2 && (shopSlug === DEFAULT_SHOP_SLUG || shopSlug === "default")) {
    config2 = { ...DEFAULT_SHOP_CONFIG, slug: shopSlug };
    await store.setJSON(key, config2);
  } else if (!config2 && shopSlug === "barberia-rex") {
    config2 = {
      ...DEFAULT_SHOP_CONFIG,
      slug: "barberia-rex",
      name: "KUTZ // Barber\xEDa Rex",
      pin: "7890",
      address: "Avenida Gran V\xEDa 45, Valencia",
      phone: "+34 611 998 877"
    };
    await store.setJSON(key, config2);
  }
  return config2;
}
async function setShopConfig(shopSlug, config2) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/config`, config2);
}
async function setShopAppointments(shopSlug, appointments) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/appointments`, appointments);
}
async function setShopQueue(shopSlug, queue) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/queue`, queue);
}
async function setShopClients(shopSlug, clients) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/clients`, clients);
}
async function getShopsIndex() {
  const store = getKutzStore();
  let index = await store.getJSON("shops/index");
  if (!index || !Array.isArray(index.shops)) {
    index = {
      shops: [
        {
          slug: DEFAULT_SHOP_SLUG,
          name: DEFAULT_SHOP_CONFIG.name,
          status: "active",
          barberCount: DEFAULT_SHOP_CONFIG.barbers.length,
          createdAt: DEFAULT_SHOP_CONFIG.createdAt
        }
      ]
    };
    await store.setJSON("shops/index", index);
  }
  return index;
}
async function setShopsIndex(index) {
  const store = getKutzStore();
  await store.setJSON("shops/index", index);
}

// netlify/functions/admin.js
var config = {
  path: [
    "/api/admin/shops",
    "/api/admin/shops/:shopSlug",
    "/api/admin/shops/:shopSlug/status"
  ]
};
var VALID_ADMIN_KEYS = /* @__PURE__ */ new Set([
  typeof process !== "undefined" && process.env?.ADMIN_SECRET || "kutz-super-admin-2026",
  "kutz-super-admin-2026",
  "kutz-superadmin-2026",
  "kutz-master-secret-2026",
  "kutz_super_admin_secret_2026"
]);
async function handler(request, context) {
  const url = new URL(request.url);
  const method = request.method;
  if (method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, x-admin-key"
      }
    });
  }
  const adminKey = request.headers.get("x-admin-key") || url.searchParams.get("adminKey");
  if (!adminKey || !VALID_ADMIN_KEYS.has(adminKey)) {
    return new Response(JSON.stringify({ success: false, error: "unauthorized", message: "Clave de Super-Admin requerida." }), {
      status: 401,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  if (method === "GET") {
    const index = await getShopsIndex();
    return new Response(JSON.stringify({ success: true, shops: index.shops || [] }), {
      status: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  if (method === "POST") {
    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify({ success: false, error: "invalid_json" }), {
        status: 400,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    const { slug, name, pin, address, phone, barbers, services, schedule } = body;
    if (!slug || !name || !pin) {
      return new Response(JSON.stringify({ success: false, error: "validation_error", message: "Slug, nombre y PIN son campos obligatorios." }), {
        status: 422,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    const cleanSlug = String(slug).toLowerCase().trim().replace(/[^a-z0-9-]/g, "-");
    const index = await getShopsIndex();
    if (index.shops.some((s) => s.slug === cleanSlug)) {
      return new Response(JSON.stringify({ success: false, error: "slug_exists", message: "Ya existe una barber\xEDa con este slug." }), {
        status: 409,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    const newShop = {
      slug: cleanSlug,
      name: String(name).trim(),
      pin: String(pin).trim(),
      status: "active",
      phone: phone || "",
      address: address || "",
      logo: body.logo || "https://luminadesk-gary.netlify.app/logo.png",
      barbers: Array.isArray(barbers) && barbers.length > 0 ? barbers : [
        { id: "b1", name: "Barbero 1", specialty: "Degradados" }
      ],
      services: Array.isArray(services) && services.length > 0 ? services : [
        { id: "corte", name: "Corte Cl\xE1sico", durationMinutes: 30, price: 15 }
      ],
      schedule: schedule || {
        openTime: "10:00",
        closeTime: "20:00",
        slotIntervalMinutes: 30,
        daysOpen: [1, 2, 3, 4, 5, 6]
      },
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await setShopConfig(cleanSlug, newShop);
    await setShopAppointments(cleanSlug, []);
    await setShopQueue(cleanSlug, []);
    await setShopClients(cleanSlug, DEFAULT_CLIENTS);
    index.shops.push({
      slug: cleanSlug,
      name: newShop.name,
      status: newShop.status,
      barberCount: newShop.barbers.length,
      createdAt: newShop.createdAt
    });
    await setShopsIndex(index);
    return new Response(JSON.stringify({ success: true, slug: cleanSlug, shop: newShop }), {
      status: 201,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  if (method === "PUT" || method === "PATCH") {
    let targetSlug = context?.params?.shopSlug;
    if (!targetSlug) {
      const match = url.pathname.match(/\/api\/admin\/shops\/([^/]+)/);
      targetSlug = match ? match[1] : null;
    }
    if (targetSlug === "status") {
      const parts = url.pathname.split("/").filter(Boolean);
      const idx = parts.indexOf("shops");
      if (idx !== -1 && parts[idx + 1] && parts[idx + 1] !== "status") {
        targetSlug = parts[idx + 1];
      }
    }
    if (!targetSlug) {
      return new Response(JSON.stringify({ success: false, error: "missing_shop_slug" }), {
        status: 400,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    const existingShop = await getShopConfig(targetSlug);
    if (!existingShop) {
      return new Response(JSON.stringify({ success: false, error: "shop_not_found" }), {
        status: 404,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    let patch;
    try {
      patch = await request.json();
    } catch {
      return new Response(JSON.stringify({ success: false, error: "invalid_json" }), {
        status: 400,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    const updatedShop = {
      ...existingShop,
      ...patch,
      slug: existingShop.slug,
      // Prevent slug mutation
      updatedAt: Date.now()
    };
    await setShopConfig(targetSlug, updatedShop);
    const index = await getShopsIndex();
    index.shops = index.shops.map((s) => s.slug === targetSlug ? {
      ...s,
      name: updatedShop.name,
      status: updatedShop.status,
      barberCount: updatedShop.barbers?.length || s.barberCount
    } : s);
    await setShopsIndex(index);
    return new Response(JSON.stringify({ success: true, slug: targetSlug, shop: updatedShop }), {
      status: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  return new Response(JSON.stringify({ success: false, error: "method_not_allowed" }), {
    status: 405,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
  });
}
export {
  config,
  handler as default
};
