
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/blobsClient.js
import { getStore } from "@netlify/blobs";
var memoryStore = /* @__PURE__ */ new Map();
var STORE_NAME = "kutz_platform";
var DEFAULT_SHOP_SLUG = "kutz-madrid";
var DEFAULT_SHOP_CONFIG = {
  slug: "kutz-madrid",
  name: "KUTZ // BARBER STUDIO",
  pin: "1234",
  status: "active",
  phone: "+34 912 345 678",
  address: "Calle de Fuencarral 42, Madrid",
  logo: "https://luminadesk-gary.netlify.app/logo.png",
  barbers: [
    { id: "rex", name: "REX", specialty: "Degradados & Skin Fade", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300" },
    { id: "kiko", name: "KIKO", specialty: "Corte & Street", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300" },
    { id: "nico", name: "NICO", specialty: "Barba & Tijera", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=300" }
  ],
  services: [
    { id: "skin-fade", name: "Skin Fade #000 + Navaja", durationMinutes: 30, price: 18, description: "Degradado afeitado a cero con navaja y acabado mate" },
    { id: "taper-fade", name: "Low Taper + Ritual Toalla", durationMinutes: 35, price: 20, description: "Taper bajo pulido con toalla caliente infusionada" },
    { id: "beard-ritual", name: "Barba & Vapor de Ozono", durationMinutes: 25, price: 15, description: "Afeitado cl\xE1sico con vaporizador y b\xE1lsamo" },
    { id: "full-combo", name: "Full Combo (Corte + Barba)", durationMinutes: 50, price: 30, description: "Servicio completo de corte degradado y arreglo de barba" }
  ],
  schedule: {
    openTime: "10:00",
    closeTime: "20:30",
    slotIntervalMinutes: 30,
    workDays: [1, 2, 3, 4, 5, 6],
    daysOpen: [1, 2, 3, 4, 5, 6]
    // Mon-Sat
  },
  createdAt: 1763e9,
  updatedAt: 1763e9
};
function isBlobsConfigured() {
  if (typeof process === "undefined" || !process.env) return false;
  return Boolean(
    process.env.NETLIFY_BLOBS_CONTEXT || process.env.NETLIFY_SITE_ID && process.env.NETLIFY_TOKEN || process.env.NETLIFY && process.env.NETLIFY_SITE_ID
  );
}
function getKutzStore() {
  let realStore = null;
  if (isBlobsConfigured()) {
    try {
      realStore = getStore({
        name: STORE_NAME,
        consistency: "strong"
      });
    } catch (err) {
      console.warn("[BlobsClient] Netlify Blobs init fallback to memory:", err?.message);
    }
  }
  const memAdapter = {
    async get(key, options = {}) {
      const val = memoryStore.get(key);
      if (val === void 0 || val === null) return null;
      if (options.type === "json") {
        try {
          return typeof val === "string" ? JSON.parse(val) : val;
        } catch {
          return null;
        }
      }
      return val;
    },
    async getJSON(key) {
      const val = memoryStore.get(key);
      if (val === void 0 || val === null) return null;
      try {
        return typeof val === "string" ? JSON.parse(val) : val;
      } catch {
        return null;
      }
    },
    async set(key, value) {
      memoryStore.set(key, typeof value === "string" ? value : JSON.stringify(value));
    },
    async setJSON(key, value) {
      memoryStore.set(key, JSON.stringify(value));
    },
    async delete(key) {
      memoryStore.delete(key);
    },
    async list(options = {}) {
      const prefix = options.prefix || "";
      const blobs = [];
      for (const [k] of memoryStore.entries()) {
        if (k.startsWith(prefix)) {
          blobs.push({ key: k });
        }
      }
      return { blobs };
    }
  };
  if (!realStore) return memAdapter;
  return {
    async get(key, options = {}) {
      try {
        return await realStore.get(key, options);
      } catch {
        return memAdapter.get(key, options);
      }
    },
    async getJSON(key) {
      try {
        if (typeof realStore.getJSON === "function") {
          return await realStore.getJSON(key);
        }
        return await realStore.get(key, { type: "json" });
      } catch {
        return memAdapter.getJSON(key);
      }
    },
    async set(key, value) {
      await memAdapter.set(key, value);
      try {
        await realStore.set(key, typeof value === "string" ? value : JSON.stringify(value));
      } catch {
      }
    },
    async setJSON(key, value) {
      await memAdapter.setJSON(key, value);
      try {
        if (typeof realStore.setJSON === "function") {
          await realStore.setJSON(key, value);
        } else {
          await realStore.set(key, JSON.stringify(value));
        }
      } catch {
      }
    },
    async delete(key) {
      await memAdapter.delete(key);
      try {
        await realStore.delete(key);
      } catch {
      }
    },
    async list(options = {}) {
      try {
        return await realStore.list(options);
      } catch {
        return memAdapter.list(options);
      }
    }
  };
}
function normalizePhone(phone) {
  if (!phone) return "";
  const digits = String(phone).replace(/\D/g, "");
  return digits.length >= 9 ? digits.slice(-9) : digits;
}
async function getShopConfig(shopSlug) {
  const store = getKutzStore();
  const key = `shops/${shopSlug}/config`;
  let config2 = await store.getJSON(key);
  if (!config2 && (shopSlug === DEFAULT_SHOP_SLUG || shopSlug === "default")) {
    config2 = { ...DEFAULT_SHOP_CONFIG, slug: shopSlug };
    await store.setJSON(key, config2);
  } else if (!config2 && shopSlug === "barberia-rex") {
    config2 = {
      ...DEFAULT_SHOP_CONFIG,
      slug: "barberia-rex",
      name: "KUTZ // Barber\xEDa Rex",
      pin: "7890",
      address: "Avenida Gran V\xEDa 45, Valencia",
      phone: "+34 611 998 877"
    };
    await store.setJSON(key, config2);
  }
  return config2;
}
async function getShopAppointments(shopSlug) {
  const store = getKutzStore();
  const appointments = await store.getJSON(`shops/${shopSlug}/appointments`);
  return Array.isArray(appointments) ? appointments : [];
}
async function setShopAppointments(shopSlug, appointments) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/appointments`, appointments);
}
async function getShopQueue(shopSlug) {
  const store = getKutzStore();
  const queue = await store.getJSON(`shops/${shopSlug}/queue`);
  return Array.isArray(queue) ? queue : [];
}
async function setShopQueue(shopSlug, queue) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/queue`, queue);
}
var shopLocks = /* @__PURE__ */ new Map();
async function withShopLock(shopSlug, fn) {
  const currentKey = shopSlug || "global";
  const prevPromise = shopLocks.get(currentKey) || Promise.resolve();
  let release;
  const lockPromise = new Promise((resolve) => {
    release = resolve;
  });
  shopLocks.set(currentKey, lockPromise);
  try {
    await prevPromise.catch(() => {
    });
    return await fn();
  } finally {
    release();
    if (shopLocks.get(currentKey) === lockPromise) {
      shopLocks.delete(currentKey);
    }
  }
}

// netlify/functions/booking.js
var config = {
  path: [
    "/api/shops/:shopSlug/public-state",
    "/api/shops/:shopSlug/booking"
  ]
};
function getScheduleMinutes(timeVal, defaultVal) {
  if (typeof timeVal === "number") {
    return timeVal * 60;
  }
  if (typeof timeVal === "string" && timeVal.includes(":")) {
    const [h, m] = timeVal.split(":").map(Number);
    if (!isNaN(h) && !isNaN(m)) return h * 60 + m;
  }
  return defaultVal;
}
function generateTimeSlots(openTime = "10:00", closeTime = "20:30", intervalMinutes = 30) {
  const slots = [];
  const [openHour, openMin] = openTime.split(":").map(Number);
  const [closeHour, closeMin] = closeTime.split(":").map(Number);
  let currentMinutes = (openHour || 10) * 60 + (openMin || 0);
  const endMinutes = (closeHour || 20) * 60 + (closeMin || 30);
  const step = Number(intervalMinutes) || 30;
  while (currentMinutes + step <= endMinutes) {
    const h = String(Math.floor(currentMinutes / 60)).padStart(2, "0");
    const m = String(currentMinutes % 60).padStart(2, "0");
    slots.push(`${h}:${m}`);
    currentMinutes += step;
  }
  return slots;
}
async function handler(request, context) {
  const url = new URL(request.url);
  const method = request.method;
  if (method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, x-shop-pin, x-admin-key"
      }
    });
  }
  let shopSlug = context?.params?.shopSlug;
  if (!shopSlug) {
    const match = url.pathname.match(/\/api\/shops\/([^/]+)/);
    shopSlug = match ? match[1] : url.searchParams.get("shop") || url.searchParams.get("shopSlug");
  }
  if (!shopSlug) {
    return new Response(JSON.stringify({ success: false, error: "missing_shop_slug", message: "Identificador de barber\xEDa no especificado." }), {
      status: 400,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  const shop = await getShopConfig(shopSlug);
  if (!shop || shop.status === "paused") {
    return new Response(JSON.stringify({ success: false, error: "shop_inactive", message: "Esta barber\xEDa no est\xE1 activa en este momento." }), {
      status: 404,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  if (method === "GET" && (url.pathname.includes("/public-state") || url.searchParams.get("action") === "public-state")) {
    const targetDate = url.searchParams.get("date") || (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const appointments = await getShopAppointments(shopSlug);
    const queue = await getShopQueue(shopSlug);
    const now = Date.now();
    const dayAppointments = appointments.filter((a) => {
      if (a.date !== targetDate) return false;
      if (a.status === "confirmed" || a.status === "seated") return true;
      if (a.status === "pending" && a.holdExpiresAt && a.holdExpiresAt > now) return true;
      return false;
    });
    const timeSlots = generateTimeSlots(
      shop.schedule?.openTime,
      shop.schedule?.closeTime,
      shop.schedule?.slotIntervalMinutes
    );
    const barbers = shop.barbers || [];
    const availability = timeSlots.map((time) => {
      const barberAvailability = barbers.map((b) => {
        const isBooked = dayAppointments.some((a) => {
          const aptTime = a.timeSlot || a.time;
          return aptTime === time && (a.barberId === b.id || a.barberId === "any" || a.barber === b.name);
        });
        return { barberId: b.id, available: !isBooked };
      });
      const anyAvailable = barberAvailability.some((b) => b.available);
      return {
        time,
        available: anyAvailable,
        barbers: barberAvailability
      };
    });
    const activeWaitingQueue = queue.filter((q) => q.status === "waiting");
    const anonymizedQueue = {
      count: activeWaitingQueue.length,
      waitMinutes: activeWaitingQueue.reduce((acc, q) => acc + (Number(q.waitMinutes) || 20), 0),
      entries: activeWaitingQueue.map((_q, idx) => ({
        position: idx + 1,
        waitMinutes: (idx + 1) * 20
      }))
    };
    const publicState = {
      success: true,
      shop: {
        slug: shop.slug,
        name: shop.name,
        address: shop.address,
        phone: shop.phone,
        logo: shop.logo,
        barbers: shop.barbers,
        services: shop.services,
        schedule: shop.schedule
      },
      date: targetDate,
      availability,
      queue: anonymizedQueue
    };
    return new Response(JSON.stringify(publicState), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-store, max-age=0"
      }
    });
  }
  if (method === "POST" && (url.pathname.includes("/booking") || url.searchParams.get("action") === "booking")) {
    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify({ success: false, error: "invalid_json", message: "Cuerpo de solicitud inv\xE1lido." }), {
        status: 400,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    const { type, clientName, clientPhone, indicativeStyle } = body;
    if (!clientName || !clientPhone) {
      return new Response(JSON.stringify({ success: false, error: "validation_error", message: "Nombre y tel\xE9fono son obligatorios." }), {
        status: 422,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    const normalizedClientPhone = normalizePhone(clientPhone);
    if (type === "appointment") {
      const { barberId, serviceId, date, timeSlot, time, notes } = body;
      const slotTime = timeSlot || time;
      if (!date || !slotTime) {
        return new Response(JSON.stringify({ success: false, error: "missing_time_slot", message: "Fecha y hora requeridas." }), {
          status: 422,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      const openDays = shop.schedule?.workDays || shop.schedule?.daysOpen || [1, 2, 3, 4, 5, 6];
      const dateParts = String(date).split("-").map(Number);
      if (dateParts.length !== 3 || dateParts.some(isNaN)) {
        return new Response(JSON.stringify({
          success: false,
          error: "shop_closed_on_date",
          message: "Fecha inv\xE1lida."
        }), {
          status: 400,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      const dateObj = new Date(Date.UTC(dateParts[0], dateParts[1] - 1, dateParts[2]));
      if (isNaN(dateObj.getTime())) {
        return new Response(JSON.stringify({
          success: false,
          error: "shop_closed_on_date",
          message: "Fecha inv\xE1lida."
        }), {
          status: 400,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      const dayOfWeek = dateObj.getUTCDay();
      const isOpen = openDays.includes(dayOfWeek) || dayOfWeek === 0 && openDays.includes(7);
      if (!isOpen) {
        return new Response(JSON.stringify({
          success: false,
          error: "shop_closed_on_date",
          message: "La barber\xEDa permanece cerrada este d\xEDa."
        }), {
          status: 400,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      const [sh, sm] = String(slotTime).split(":").map(Number);
      if (isNaN(sh) || isNaN(sm)) {
        return new Response(JSON.stringify({ success: false, error: "outside_business_hours", message: "Formato de hora inv\xE1lido." }), {
          status: 400,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      const slotMinutes = sh * 60 + sm;
      const openMinutes = getScheduleMinutes(shop.schedule?.openTime ?? shop.schedule?.startHour, 10 * 60);
      const closeMinutes = getScheduleMinutes(shop.schedule?.closeTime ?? shop.schedule?.endHour, 20 * 60 + 30);
      if (slotMinutes < openMinutes || slotMinutes >= closeMinutes) {
        return new Response(JSON.stringify({
          success: false,
          error: "outside_business_hours",
          message: "Horario fuera del horario comercial."
        }), {
          status: 400,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      return await withShopLock(shopSlug, async () => {
        const appointments = await getShopAppointments(shopSlug);
        const now = Date.now();
        const collision = appointments.find((a) => {
          const aptTime = a.timeSlot || a.time;
          if (a.date !== date || aptTime !== slotTime) return false;
          if (barberId && a.barberId !== "any" && barberId !== "any" && a.barberId !== barberId) return false;
          if (a.status === "confirmed" || a.status === "seated") return true;
          if (a.status === "pending" && a.holdExpiresAt && a.holdExpiresAt > now) return true;
          return false;
        });
        if (collision) {
          return new Response(JSON.stringify({
            success: false,
            error: "slot_unavailable",
            message: "El hueco seleccionado ya no est\xE1 disponible o tiene una reserva en curso."
          }), {
            status: 409,
            headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
          });
        }
        const holdDurationMs = 10 * 60 * 1e3;
        const newAppointment = {
          id: `apt-${now}-${Math.random().toString(36).slice(2, 7)}`,
          shopSlug,
          type: "appointment",
          clientName: String(clientName).trim(),
          clientPhone: normalizedClientPhone,
          rawPhone: clientPhone,
          barberId: barberId || "any",
          serviceId: serviceId || "skin-fade",
          date,
          timeSlot: slotTime,
          time: slotTime,
          indicativeStyle: indicativeStyle || "",
          notes: notes || "",
          status: "pending",
          createdAt: now,
          holdExpiresAt: now + holdDurationMs
        };
        appointments.push(newAppointment);
        await setShopAppointments(shopSlug, appointments);
        return new Response(JSON.stringify({
          success: true,
          bookingId: newAppointment.id,
          status: "pending",
          holdExpiresAt: newAppointment.holdExpiresAt,
          message: "Solicitud enviada con \xE9xito. El barbero revisar\xE1 tu reserva en unos instantes."
        }), {
          status: 201,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      });
    }
    if (type === "walkin") {
      const { barberId, serviceId } = body;
      return await withShopLock(shopSlug, async () => {
        const queue = await getShopQueue(shopSlug);
        const now = Date.now();
        const waitingCount = queue.filter((q) => q.status === "waiting").length;
        const position = waitingCount + 1;
        const waitMinutes = position * 20;
        const newQueueItem = {
          id: `wq-${now}-${Math.random().toString(36).slice(2, 7)}`,
          shopSlug,
          type: "walkin",
          name: String(clientName).trim(),
          phone: normalizedClientPhone,
          rawPhone: clientPhone,
          barber: barberId || "Cualquiera",
          service: serviceId || "Skin Fade Express",
          indicativeStyle: indicativeStyle || "",
          position,
          waitMinutes,
          status: "waiting",
          timeIn: new Date(now).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }),
          createdAt: now
        };
        queue.push(newQueueItem);
        await setShopQueue(shopSlug, queue);
        return new Response(JSON.stringify({
          success: true,
          bookingId: newQueueItem.id,
          status: "waiting",
          position,
          waitMinutes,
          message: `\xA1Te has apuntado a la cola! Eres el n\xFAmero #${position} en turno (~${waitMinutes} min).`
        }), {
          status: 201,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      });
    }
    return new Response(JSON.stringify({ success: false, error: "invalid_type", message: 'Tipo de reserva debe ser "appointment" o "walkin".' }), {
      status: 400,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  return new Response(JSON.stringify({ success: false, error: "not_found" }), {
    status: 404,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
  });
}
export {
  config,
  handler as default
};
