
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/blobsClient.js
import { getStore } from "@netlify/blobs";
var memoryStore = /* @__PURE__ */ new Map();
var STORE_NAME = "kutz_platform";
var DEFAULT_SHOP_SLUG = "kutz-madrid";
var DEFAULT_SHOP_CONFIG = {
  slug: "kutz-madrid",
  name: "KUTZ // BARBER STUDIO",
  pin: "1234",
  status: "active",
  phone: "+34 912 345 678",
  address: "Calle de Fuencarral 42, Madrid",
  logo: "https://luminadesk-gary.netlify.app/logo.png",
  barbers: [
    { id: "rex", name: "REX", specialty: "Degradados & Skin Fade", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300" },
    { id: "kiko", name: "KIKO", specialty: "Corte & Street", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300" },
    { id: "nico", name: "NICO", specialty: "Barba & Tijera", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=300" }
  ],
  services: [
    { id: "skin-fade", name: "Skin Fade #000 + Navaja", durationMinutes: 30, price: 18, description: "Degradado afeitado a cero con navaja y acabado mate" },
    { id: "taper-fade", name: "Low Taper + Ritual Toalla", durationMinutes: 35, price: 20, description: "Taper bajo pulido con toalla caliente infusionada" },
    { id: "beard-ritual", name: "Barba & Vapor de Ozono", durationMinutes: 25, price: 15, description: "Afeitado cl\xE1sico con vaporizador y b\xE1lsamo" },
    { id: "full-combo", name: "Full Combo (Corte + Barba)", durationMinutes: 50, price: 30, description: "Servicio completo de corte degradado y arreglo de barba" }
  ],
  schedule: {
    openTime: "10:00",
    closeTime: "20:30",
    slotIntervalMinutes: 30,
    workDays: [1, 2, 3, 4, 5, 6],
    daysOpen: [1, 2, 3, 4, 5, 6]
    // Mon-Sat
  },
  createdAt: 1763e9,
  updatedAt: 1763e9
};
var DEFAULT_CLIENTS = [
  {
    id: "1",
    name: "Marcos Varela",
    phone: "+34 611 223 344",
    treatment: "Mid Fade + Barba",
    treatments: [
      {
        id: "t-1",
        name: "Mid Fade + Barba",
        formula: "Base #0.5 \u2192 Peine #1.5 palanca abierta. Barba perfilada con navaja",
        notes: "Remolino en coronilla derecha; peinar hacia adelante",
        date: "28 Oct 2026",
        timestamp: 17616096e5
      }
    ],
    reliabilityScore: 100,
    noShowCount: 0
  },
  {
    id: "2",
    name: "Dani Morales",
    phone: "+34 633 445 566",
    treatment: "Low Taper + Ritual Toalla",
    treatments: [
      {
        id: "t-2",
        name: "Low Taper + Ritual Toalla",
        formula: "Taper bajo en patillas y nuca. Tijera texturizada superior",
        notes: "Piel sensible en cuello; usar loci\xF3n sin alcohol",
        date: "29 Oct 2026",
        timestamp: 1761696e6
      }
    ],
    reliabilityScore: 95,
    noShowCount: 0
  },
  {
    id: "3",
    name: "\xC1lex Rivera",
    phone: "+34 622 334 455",
    treatment: "Skin Fade #000 + Navaja",
    treatments: [
      {
        id: "t-3",
        name: "Skin Fade #000 + Navaja",
        formula: "Base Shaver #000 \u2192 #0.5 \u2192 #1.5. Acabado mate polvo volumen",
        notes: "Pelo grueso muy denso. Pulir bien zona occipital",
        date: "29 Oct 2026",
        timestamp: 1761696e6
      }
    ],
    reliabilityScore: 100,
    noShowCount: 0
  }
];
function isBlobsConfigured() {
  if (typeof process === "undefined" || !process.env) return false;
  return Boolean(
    process.env.NETLIFY_BLOBS_CONTEXT || process.env.NETLIFY_SITE_ID && process.env.NETLIFY_TOKEN || process.env.NETLIFY && process.env.NETLIFY_SITE_ID
  );
}
function getKutzStore() {
  let realStore = null;
  if (isBlobsConfigured()) {
    try {
      realStore = getStore({
        name: STORE_NAME,
        consistency: "strong"
      });
    } catch (err) {
      console.warn("[BlobsClient] Netlify Blobs init fallback to memory:", err?.message);
    }
  }
  const memAdapter = {
    async get(key, options = {}) {
      const val = memoryStore.get(key);
      if (val === void 0 || val === null) return null;
      if (options.type === "json") {
        try {
          return typeof val === "string" ? JSON.parse(val) : val;
        } catch {
          return null;
        }
      }
      return val;
    },
    async getJSON(key) {
      const val = memoryStore.get(key);
      if (val === void 0 || val === null) return null;
      try {
        return typeof val === "string" ? JSON.parse(val) : val;
      } catch {
        return null;
      }
    },
    async set(key, value) {
      memoryStore.set(key, typeof value === "string" ? value : JSON.stringify(value));
    },
    async setJSON(key, value) {
      memoryStore.set(key, JSON.stringify(value));
    },
    async delete(key) {
      memoryStore.delete(key);
    },
    async list(options = {}) {
      const prefix = options.prefix || "";
      const blobs = [];
      for (const [k] of memoryStore.entries()) {
        if (k.startsWith(prefix)) {
          blobs.push({ key: k });
        }
      }
      return { blobs };
    }
  };
  if (!realStore) return memAdapter;
  return {
    async get(key, options = {}) {
      try {
        return await realStore.get(key, options);
      } catch {
        return memAdapter.get(key, options);
      }
    },
    async getJSON(key) {
      try {
        if (typeof realStore.getJSON === "function") {
          return await realStore.getJSON(key);
        }
        return await realStore.get(key, { type: "json" });
      } catch {
        return memAdapter.getJSON(key);
      }
    },
    async set(key, value) {
      await memAdapter.set(key, value);
      try {
        await realStore.set(key, typeof value === "string" ? value : JSON.stringify(value));
      } catch {
      }
    },
    async setJSON(key, value) {
      await memAdapter.setJSON(key, value);
      try {
        if (typeof realStore.setJSON === "function") {
          await realStore.setJSON(key, value);
        } else {
          await realStore.set(key, JSON.stringify(value));
        }
      } catch {
      }
    },
    async delete(key) {
      await memAdapter.delete(key);
      try {
        await realStore.delete(key);
      } catch {
      }
    },
    async list(options = {}) {
      try {
        return await realStore.list(options);
      } catch {
        return memAdapter.list(options);
      }
    }
  };
}
function normalizePhone(phone) {
  if (!phone) return "";
  const digits = String(phone).replace(/\D/g, "");
  return digits.length >= 9 ? digits.slice(-9) : digits;
}
async function getShopConfig(shopSlug) {
  const store = getKutzStore();
  const key = `shops/${shopSlug}/config`;
  let config2 = await store.getJSON(key);
  if (!config2 && (shopSlug === DEFAULT_SHOP_SLUG || shopSlug === "default")) {
    config2 = { ...DEFAULT_SHOP_CONFIG, slug: shopSlug };
    await store.setJSON(key, config2);
  } else if (!config2 && shopSlug === "barberia-rex") {
    config2 = {
      ...DEFAULT_SHOP_CONFIG,
      slug: "barberia-rex",
      name: "KUTZ // Barber\xEDa Rex",
      pin: "7890",
      address: "Avenida Gran V\xEDa 45, Valencia",
      phone: "+34 611 998 877"
    };
    await store.setJSON(key, config2);
  }
  return config2;
}
async function getShopAppointments(shopSlug) {
  const store = getKutzStore();
  const appointments = await store.getJSON(`shops/${shopSlug}/appointments`);
  return Array.isArray(appointments) ? appointments : [];
}
async function setShopAppointments(shopSlug, appointments) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/appointments`, appointments);
}
async function getShopQueue(shopSlug) {
  const store = getKutzStore();
  const queue = await store.getJSON(`shops/${shopSlug}/queue`);
  return Array.isArray(queue) ? queue : [];
}
async function setShopQueue(shopSlug, queue) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/queue`, queue);
}
async function getShopClients(shopSlug) {
  const store = getKutzStore();
  const key = `shops/${shopSlug}/clients`;
  let clients = await store.getJSON(key);
  if (!clients && (shopSlug === DEFAULT_SHOP_SLUG || shopSlug === "default")) {
    clients = DEFAULT_CLIENTS;
    await store.setJSON(key, clients);
  }
  return Array.isArray(clients) ? clients : [];
}
async function setShopClients(shopSlug, clients) {
  const store = getKutzStore();
  await store.setJSON(`shops/${shopSlug}/clients`, clients);
}

// netlify/functions/sync.js
var config = {
  path: "/api/shops/:shopSlug/sync"
};
function formatWhatsAppNumber(phone) {
  if (!phone) return null;
  const digits = String(phone).replace(/\D/g, "");
  if (!digits || digits.length < 9) return null;
  if (digits.length === 9) {
    return `34${digits}`;
  }
  return digits;
}
async function handler(request, context) {
  const url = new URL(request.url);
  const method = request.method;
  if (method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, x-shop-pin"
      }
    });
  }
  let shopSlug = context?.params?.shopSlug;
  if (!shopSlug) {
    const match = url.pathname.match(/\/api\/shops\/([^/]+)/);
    shopSlug = match ? match[1] : url.searchParams.get("shop") || url.searchParams.get("shopSlug");
  }
  if (!shopSlug) {
    return new Response(JSON.stringify({ success: false, error: "missing_shop_slug" }), {
      status: 400,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  const shop = await getShopConfig(shopSlug);
  if (!shop) {
    return new Response(JSON.stringify({ success: false, error: "shop_not_found" }), {
      status: 404,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  const providedPin = request.headers.get("x-shop-pin") || url.searchParams.get("pin");
  if (!providedPin || providedPin !== shop.pin) {
    return new Response(JSON.stringify({ success: false, error: "unauthorized", message: "PIN incorrecto o no suministrado." }), {
      status: 401,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  if (method === "GET") {
    let appointments = await getShopAppointments(shopSlug);
    const queue = await getShopQueue(shopSlug);
    const clients = await getShopClients(shopSlug);
    const now = Date.now();
    let hasExpiredChanges = false;
    appointments = appointments.map((a) => {
      if (a.status === "pending" && a.holdExpiresAt && a.holdExpiresAt <= now) {
        hasExpiredChanges = true;
        return { ...a, status: "expired" };
      }
      return a;
    });
    if (hasExpiredChanges) {
      await setShopAppointments(shopSlug, appointments);
    }
    const enrichedAppointments = appointments.map((apt) => {
      const normPhone = normalizePhone(apt.clientPhone || apt.phone);
      const matchedClient = clients.find((c) => normalizePhone(c.phone) === normPhone);
      return {
        ...apt,
        matchedClientId: matchedClient ? matchedClient.id : null,
        hasExistingCard: Boolean(matchedClient),
        latestFormula: matchedClient?.treatments?.[0]?.formula || null
      };
    });
    return new Response(JSON.stringify({
      success: true,
      shopSlug,
      timestamp: now,
      config: shop,
      appointments: enrichedAppointments,
      queue,
      clients
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-store, max-age=0"
      }
    });
  }
  if (method === "POST") {
    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify({ success: false, error: "invalid_json" }), {
        status: 400,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    const { action, payload = {} } = body;
    const appointments = await getShopAppointments(shopSlug);
    const queue = await getShopQueue(shopSlug);
    const clients = await getShopClients(shopSlug);
    if (action === "approve") {
      const appointmentId = payload?.appointmentId || payload?.id;
      const targetIndex = appointments.findIndex((a) => a.id === appointmentId);
      if (targetIndex === -1) {
        return new Response(JSON.stringify({ success: false, error: "appointment_not_found" }), {
          status: 404,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      const target = appointments[targetIndex];
      target.status = "confirmed";
      target.holdExpiresAt = null;
      target.confirmedAt = Date.now();
      const normPhone = normalizePhone(target.clientPhone || target.phone);
      let matchedClient = clients.find((c) => normalizePhone(c.phone) === normPhone);
      if (!matchedClient) {
        matchedClient = {
          id: `c-${Date.now()}`,
          name: target.clientName,
          phone: target.clientPhone || target.phone,
          avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300",
          indicativeStyle: target.indicativeStyle || "Skin Fade",
          treatment: target.indicativeStyle ? `Corte ${target.indicativeStyle}` : "Corte Inicial",
          lastVisit: "Alta QR",
          treatments: [
            {
              id: `t-${Date.now()}`,
              name: target.indicativeStyle ? `Estilo ${target.indicativeStyle}` : "Corte Inicial",
              date: target.date,
              timestamp: Date.now(),
              formula: `Estilo inicial: ${target.indicativeStyle || "Skin Fade"} (Guardar peines tras corte)`,
              notes: target.notes || "Alta autom\xE1tica desde reserva online QR"
            }
          ],
          reliabilityScore: 100,
          noShowCount: 0,
          bonos: []
        };
        clients.push(matchedClient);
        await setShopClients(shopSlug, clients);
      }
      target.matchedClientId = matchedClient.id;
      appointments[targetIndex] = target;
      await setShopAppointments(shopSlug, appointments);
      const clientRawPhone = target.rawPhone || target.clientPhone || target.phone || "";
      const waPhone = formatWhatsAppNumber(clientRawPhone);
      const targetTime = target.timeSlot || target.time;
      const waMsg = `\xA1Buenas ${target.clientName}! \u{1F488} Tu cita en ${shop.name} ha sido CONFIRMADA para el ${target.date} a las ${targetTime} con ${target.barberId || "tu barbero"}. \xA1Te esperamos en ${shop.address}!`;
      const whatsappUrl = waPhone ? `https://wa.me/${waPhone}?text=${encodeURIComponent(waMsg)}` : null;
      return new Response(JSON.stringify({
        success: true,
        action: "approve",
        appointment: target,
        matchedClient,
        whatsappUrl
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    if (action === "reject") {
      const appointmentId = payload?.appointmentId || payload?.id;
      const alternativeSlot = payload?.alternativeSlot;
      const targetIndex = appointments.findIndex((a) => a.id === appointmentId);
      if (targetIndex === -1) {
        return new Response(JSON.stringify({ success: false, error: "appointment_not_found" }), {
          status: 404,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      const target = appointments[targetIndex];
      target.status = "rejected";
      target.holdExpiresAt = null;
      appointments[targetIndex] = target;
      await setShopAppointments(shopSlug, appointments);
      const clientRawPhone = target.rawPhone || target.clientPhone || target.phone || "";
      const waPhone = formatWhatsAppNumber(clientRawPhone);
      const altText = alternativeSlot ? ` \xBFTe vendr\xEDa bien moverla a las ${alternativeSlot}?` : " Por favor, revisa otros horarios disponibles en la web.";
      const targetTime = target.timeSlot || target.time;
      const waMsg = `Buenas ${target.clientName}, no podemos atender tu cita para el ${target.date} a las ${targetTime}.${altText}`;
      const whatsappUrl = waPhone ? `https://wa.me/${waPhone}?text=${encodeURIComponent(waMsg)}` : null;
      return new Response(JSON.stringify({
        success: true,
        action: "reject",
        appointmentId,
        whatsappUrl
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    if (action === "seat") {
      const { queueId, chairId, appointmentId } = payload;
      let updatedQueue = queue;
      if (queueId) {
        updatedQueue = queue.filter((q) => q.id !== queueId);
        await setShopQueue(shopSlug, updatedQueue);
      }
      if (appointmentId) {
        const aptIndex = appointments.findIndex((a) => a.id === appointmentId);
        if (aptIndex !== -1) {
          appointments[aptIndex].status = "seated";
          appointments[aptIndex].chairId = chairId;
          await setShopAppointments(shopSlug, appointments);
        }
      }
      return new Response(JSON.stringify({
        success: true,
        action: "seat",
        chairId,
        queueId,
        appointmentId
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    if (action === "finish") {
      const { chairId, clientId, formulaNotes } = payload;
      if (clientId && formulaNotes) {
        const clientIndex = clients.findIndex((c) => String(c.id) === String(clientId));
        if (clientIndex !== -1) {
          const client = clients[clientIndex];
          client.treatments = [
            {
              id: `t-${Date.now()}`,
              name: "Corte en Sill\xF3n",
              formula: formulaNotes,
              date: (/* @__PURE__ */ new Date()).toLocaleDateString("es-ES", { day: "2-digit", month: "short", year: "numeric" }),
              timestamp: Date.now()
            },
            ...client.treatments || []
          ];
          client.completedVisits = (client.completedVisits || 0) + 1;
          clients[clientIndex] = client;
          await setShopClients(shopSlug, clients);
        }
      }
      return new Response(JSON.stringify({
        success: true,
        action: "finish",
        chairId
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    return new Response(JSON.stringify({ success: false, error: "unknown_action" }), {
      status: 400,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
  return new Response(JSON.stringify({ success: false, error: "method_not_allowed" }), {
    status: 405,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
  });
}
export {
  config,
  handler as default,
  formatWhatsAppNumber
};
